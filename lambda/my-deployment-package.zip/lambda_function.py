from streaming_form_data import StreamingFormDataParser
from streaming_form_data.targets import ValueTarget
import base64


def lambda_handler(event, context):
    
    parser = StreamingFormDataParser(headers=event['headers'])
    user_full_name = ValueTarget()
    uploaded_file = ValueTarget()
    
    parser.register("name", user_full_name)
    parser.register("xlsx", uploaded_file)

    mydata = base64.b64decode(event['body'])
    parser.data_received(mydata)
    
    data=uploaded_file.value

    with open('template.xlsx', 'rb') as f:
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition': 'attachment; filename="output3.xlsx"',
                'Hello': user_full_name.value.decode("utf-8"),
                'World': len(data),
            },
            'body': base64.b64encode(f.read()).decode('utf-8'),
            'isBase64Encoded': True
        }
